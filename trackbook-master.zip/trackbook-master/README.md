# Trackbook - Android Movement Recorder
<img src="https://raw.githubusercontent.com/y20k/trackbook/master/app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.png"
    width="192" />

## Note
This project is now read-only. It has been moved over to Codeberg. The development of this project continues at its new home.

* [Trackbook on Codeberg](https://codeberg.org/y20k/trackbook)
